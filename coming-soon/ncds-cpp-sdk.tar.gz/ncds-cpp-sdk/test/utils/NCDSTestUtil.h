//
// Created by Jennifer Wang on 7/27/21.
//

#ifndef TEST_INTEGRATION_NCDSTESTUTIL_H
#define TEST_INTEGRATION_NCDSTESTUTIL_H

#include <librdkafka/rdkafkacpp.h>
#include "avro/ValidSchema.hh"
#include <avro/GenericDatum.hh>
#include "NCDSDeliveryReportCb.h"
#include <set>

class NCDSTestUtil {
private:
    std::set<std::string> topics_on_stream;
    std::string ctrl_topic = "control";
    std::string mock_data_stream = "MOCK.stream";
    std::string GIDS_data_stream = "GIDS.stream";
    std::vector<avro::GenericRecord> mock_messages_on_stream;
    std::vector<avro::GenericRecord> GIDS_messages_on_stream;
    size_t ctrl_branch = 1;
    std::unique_ptr<RdKafka::Conf> producer_conf;
public:
    NCDSTestUtil();
    std::unique_ptr<NCDSDeliveryReportCb> delivery_report_cb;
    void add_schemas_to_control_topic();
    std::set<std::string> get_added_topics();
    std::vector<avro::GenericRecord> get_mock_messages();
    std::vector<avro::GenericRecord> get_GIDS_messages();
    avro::ValidSchema get_schema_for_topic(std::string schema_file);
    void push_mock_messages();
    void push_gids_messages();
    std::vector<avro::GenericDatum> get_mocker_generic_record(int num_records);
    std::vector<avro::GenericDatum> get_GIDS_generic_record(int num_records);

    static bool compare_records(avro::GenericRecord record_1, avro::GenericRecord record_2);

};

#endif //TEST_INTEGRATION_NCDSTESTUTIL_H
