//
// Created by Jennifer Wang on 8/5/21.
//

#ifndef NCDS_DELIVERY_REPORT_CB_H
#define NCDS_DELIVERY_REPORT_CB_H


class NCDSDeliveryReportCb : public RdKafka::DeliveryReportCb {
public:
    RdKafka::MessageTimestamp timestamp_to_seek_to;
    void dr_cb (RdKafka::Message &message) {
        /* If message.err() is non-zero the message delivery failed permanently
         * for the message. */
        if (message.err())
            std::cerr << "Message delivery failed: " << message.errstr() << std::endl;
        else
            std::cerr << "Message delivered to topic " << message.topic_name() <<
                      " [" << message.partition() << "] at offset " <<
                      message.offset() << std::endl;
        if (message.topic_name() == "MOCK.stream" && message.offset() == 2) {
            this->timestamp_to_seek_to = message.timestamp();
            std::cout << "timestamp: " << this->timestamp_to_seek_to.timestamp <<
                      " at offset " <<
                      message.offset() << std::endl;
        }
    }
};

#endif //NCDS_DELIVERY_REPORT_CB_H
