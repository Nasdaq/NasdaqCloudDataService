# Nasdaq Cloud Data Service (NCDS)

Nasdaq Cloud Data Service (NCDS) provides a modern and efficient method of delivery for realtime exchange data and other financial information. Data is made available through a suite of APIs, allowing for effortless integration of data from disparate sources, and a dramatic reduction in time to market for customer-designed applications. The API is highly scalable, and robust enough to support the delivery of real-time exchange data.  


### Items To Note

* Connecting to the API requires credentials, which are provided by the Nasdaq Data Operations team during an on-boarding process
* This sample code only connects to one topic (GIDS); during on-boarding process, you will receive a topic list that you're entitled to.
* See https://github.com/Nasdaq/CloudDataService for our officially support Java-based SDK.

# Table of Contents
 - [Getting Started](#getting-started)
 - [Using the SDK](#using-the-sdk)

## Getting Started

### Supported Operating Systems
Currently, the only operating system that is officially supported for the C++ SDK is Centos. 

This build was tested on the CentOS Stream (release 8) AMI. 

### Kafka Configuration
Edit the kafka configuration in `ncds-sdk/src/main/cpp.com.nasdaq.ncdsclient/ncdsresources/consumer-properties.json`.

`// timeout for internal kafka request functions in ms`
```json
{
"timeout": 30000 
}
```

### Logging Configuration
Edit the logging configuration in `ncds-sdk/src/main/cpp.com.nasdaq.ncdsclient/ncdsresources/logging.json`.

`//Set "debug" : 1 to enable logging`
```json
{
  "max_size": 5242880,
  "max_files": 3,
  "debug": 0
}
```

**Note**: When you install the library, take note of where the resource files are installed. 
If you need to edit the logging or kafka configuration again, the installed location is where 
they need to be modified. 


### Build from source

#### Requirements
- A C++ compiler
  - This build was tested with gcc (8.5.0)
- CMake build tool version 3.21 or later. See https://www.cmake.org for details on how to set up CMake for your system.
- Avro C++>=1.10.2 (https://avro.apache.org/docs/current/api/cpp/html/index.html)
- spdlog>=1.9.2 (https://github.com/gabime/spdlog)
- librdkafka>=1.7.0 (https://github.com/edenhill/librdkafka)
- curl>=7.78.0 (https://github.com/curl/curl)
- json-c >= 0.15 (https://github.com/json-c/json-c)

#### Building
The source code for the SDK is currently hosted on GitHub at: https://git.nasdaq.com/gis-lab/mdic/ncds-cpp-sdk ***(replace with correct github link when created)***

Clone the repository: ```git clone https://git.nasdaq.com/gis-lab/mdic/ncds-cpp-sdk.git``` ***(replace with correct github link when created)*** and run:

```
cd ncds-cpp-sdk
mkdir build && cd build
cmake .. <OPTIONS> 
make && make install
```

### CMake Options
- `NCDSRESOURCES`: Specify a different directory to install the file resources for the library. The default location is defined as `/usr/local/share` by the GNU standard installation directories (https://cmake.org/cmake/help/v3.0/module/GNUInstallDirs.html)
  **NOTE**: If a different resource installation directory is specified for the build, an environment variable will also need to be set (see [Usage](#usage) below)
- `AVRO_DIR`: Specify a different avro install directory
- `CURL_DIR`: Specify a different curl install directory
- `JSON-C_DIR`: Specify a different json-c install directory
- `RDKAFKA_DIR`: Specify a different rdkafka install directory
- `RDKAFKACPP_DIR`: Specify a different rdkafkacpp install directory
- `SPDLOG`: Specify a different spdlog install directory 

Example:
```
cmake .. -DRDKAFKA_DIR=/path/to/librdkafka -DNCDSRESOURCES=/path/to/resources
```
#### Usage 
Link your program with ```-lncds-sdk```

Define the environment variable `NCDSRESOURCES` if the resource files have been installed in a non-default location:
- Linux: `export NCDSRESOURCES="/path/to/my/dir/ncdsresources/"`.

Note here that the directory `ncdsresources` is added to the custom install path and the variable is ended with a file separator (`/` in this case).

## Examples
The example directory contains examples that will be helpful while getting started with the library.

To run the examples:

1. Edit the `GetConfigs.h` file with the appropriate values provided during on-boarding 
2. Build the example files:
```
cd examples
mkdir build && cd build
cmake .. && make
cd ..
```
3. Run an example program which uses `ncds-sdk`
```asm
./build/ncds_kafka_consumer
```

## Using the SDK

Below are several examples for how to access data using the SDK. First, create a ```kafka_config``` and ```auth_config``` to make an NCDSClient instance.

```cpp
#include <ncds-sdk/NCDSClient.h>
#include <librdkafka/rdkafkacpp.h>
#include <string>
#include <memory>

// Kafka configs
std::unique_ptr<RdKafka::Conf> kafka_config = std::unique_ptr<RdKafka::Conf>(load_test_config());
kafka_conf->set("metadata.broker.list", <brokers>, errstr);

 The consumer configuration gives the ability to fix a consumer group id which is important for production usage. Setting the consumer group id explicitly allows the kafka administrator to add protections around your production feed.
 The following is an example of a fixed consumer group id convention
 ```properties
kafka_conf->set("group.id", "{oauth.client.id}_{environment}_{feedname}", errstr);
 ```
 The following is an example of the group id filled in:
  ```properties
kafka_conf->set("group.id", "testuser_pro_totalview", errstr);
 ```
 Please note that if you fix the consumer group id in your client, you will continue at the last offset that was consumed from kafka. This is a way promote availability for your application as the app will begin where it left off given a disconnection.

 Also, if you are using the SDK for interactive query, you will also be consuming from where you last consumed. The consumer group id effectively saves the last offset that you have ingested.

... // Set additional kafka configurations 

// Security configs
std::unordered_map<std::string, std::string> auth_config = {
{"oauth.token.endpoint.uri", <token_endpoint_uri>},
{"oauth.client.id", <client_id>},
{"oauth.client.secret", <client_secret>}};

NCDSClient ncds_client(kafka_config.get(), auth_config);
```

### Getting list of data stream available
List all available data stream for the user

```cpp
std::set<std::string> list = ncds_client.list_topics_for_the_client();
for (const std::string& topic : list) {
    std::cout << topic;
}
```

Example output:
```
List of streams available on Nasdaq Cloud Data Service:
GIDS
NLSUTP
NLSCTA
```

### Getting schema for the stream
This method returns the schema for the stream in Apache Avro format (https://avro.apache.org/docs/current/spec.html)
```cpp
#include <avro/Generic.hh>
avro::ValidSchema schema = ncds_client.get_schema("GIDS");
std::cout << "schema: " << schema.toJson();
```

Example output:
```
[ {
"type" : "record",
"name" : "SeqCommoditySummary",
"namespace" : "com.nasdaq.marketdata.sequencer.applications.datafeed.gids20feed.messaging",
"fields" : [ {
"name" : "SoupPartition",
"type" : "int"
}, {
"name" : "SoupSequence",
"type" : "long"
}, {
"name" : "msgType",
"type" : "string"
}, {
"name" : "timeStamp",
"type" : "int"
}, {
"name" : "fpType",
"type" : "string"
}, {
"name" : "brand",
"type" : "string"
}, {
"name" : "series",
"type" : "string"
}, {
"name" : "instrumentID",
"type" : "string"
}, {
"name" : "summaryType",
"type" : "string"
}, {
"name" : "sodValue",
"type" : "long"
}, {
"name" : "high",
"type" : "long"
}, {
"name" : "low",
"type" : "long"
}, {
"name" : "eodValue",
"type" : "long"
}, {
"name" : "netChange",
"type" : "long"
}, {
"name" : "effectiveDate",
"type" : "int"
}, {
"name" : "currency",
"type" : "string"
} ],
"version" : "1"
}, {...
} .......
.... ]
```

### Get first 5 messages of the stream 
```cpp
// Function to print a vector of avro Generic Records. 
// ***Note*** that this implementation will depend on the types of data in your records.
void print_records(std::vector<avro::GenericRecord> &records) {
    for (auto &record : records) {
        std::cout << "Message name: " << record.schema()->name().simpleName() << std::endl;
        for (size_t i = 0; i < record.fieldCount(); i++) {
            avro::GenericDatum datum = record.fieldAt(i);
            std::cout << record.schema()->nameAt(i) << ": ";
            if (datum.type() == avro::AVRO_DOUBLE) {
                double num = datum.value<double>();
                std::cout << num << std::endl;
            } else if (datum.type() == avro::AVRO_LONG) {
                int64_t num = datum.value<int64_t>();
                std::cout << num << std::endl;
            } else if (datum.type() == avro::AVRO_INT) {
                int num = datum.value<int>();
                std::cout << num << std::endl;
            } else if (datum.type() == avro::AVRO_STRING) {
                std::string str = datum.value<std::string>();
                std::cout << str << std::endl;
            }
        }
    }
}
```
```cpp
#include <avro/Generic.hh>
std::topic = "GIDS";
auto messages = ncds_client.top_messages("GIDS", 5);
std::cout << "top messages: " << std::endl;
print_records(messages);
```

Example output
```
top messages: 
message name: SeqIndexTickDetail
SoupPartition: 0
SoupSequence: 182012109
msgType: I
timeStamp: 886537340
fpType: I
brand: NQ
series: NQG
instrumentID: NQGB4050LM        
tickValue: 106593206220785
tickDirection: +
currency: USD

message name: SeqIndexTickDetail
SoupPartition: 0
SoupSequence: 182012110
msgType: I
timeStamp: 886537583
fpType: I
brand: NQ
series: NQG
instrumentID: NQEMASIA30LM      
tickValue: 139620195251482
tickDirection: +
currency: USD

message name: SeqEtpIpvValue
SoupPartition: 0
SoupSequence: 182012111
msgType: E
timeStamp: 886783326
fpType: E
ipvSymbol: USXF.IV           
ipvValue: 3746852400000
currency: USD

message name: SeqIndexTickDetail
SoupPartition: 0
SoupSequence: 182012112
msgType: I
timeStamp: 888077532
fpType: I
brand: NQ
series: UAM
instrumentID: NQUSB40401020T    
tickValue: 319016557614170
tickDirection:  
currency: USD

message name: SeqIndexTickDetail
SoupPartition: 0
SoupSequence: 182012113
msgType: I
timeStamp: 888077789
fpType: I
brand: NQ
series: UAM
instrumentID: NQUSS651030T      
tickValue: 204655897870032
tickDirection:  
currency: USD
```

### Get first 5 messages of the stream from given timestamp 
This returns the first 5 available messages of the stream given timestamp in milliseconds since the UNIX epoch.
```cpp
#include <avro/Generic.hh>
auto messages = ncds_client.top_messages("GIDS", 1590084446510, 5);
std::cout << "top messages: " << std::endl;
print_records(messages);
```

Example output:
```
top messages: 

message name: SeqIndexTickDetail
SoupPartition: 0
SoupSequence: 182012109
msgType: I
timeStamp: 886537340
fpType: I
brand: NQ
series: NQG
instrumentID: NQGB4050LM        
tickValue: 106593206220785
tickDirection: +
currency: USD

message name: SeqIndexTickDetail
SoupPartition: 0
SoupSequence: 182012110
msgType: I
timeStamp: 886537583
fpType: I
brand: NQ
series: NQG
instrumentID: NQEMASIA30LM      
tickValue: 139620195251482
tickDirection: +
currency: USD

message name: SeqEtpIpvValue
SoupPartition: 0
SoupSequence: 182012111
msgType: E
timeStamp: 886783326
fpType: E
ipvSymbol: USXF.IV           
ipvValue: 3746852400000
currency: USD

message name: SeqIndexTickDetail
SoupPartition: 0
SoupSequence: 182012112
msgType: I
timeStamp: 888077532
fpType: I
brand: NQ
series: UAM
instrumentID: NQUSB40401020T    
tickValue: 319016557614170
tickDirection:  
currency: USD

message name: SeqIndexTickDetail
SoupPartition: 0
SoupSequence: 182012113
msgType: I
timeStamp: 888077789
fpType: I
brand: NQ
series: UAM
instrumentID: NQUSS651030T      
tickValue: 204655897870032
tickDirection:  
currency: USD
```

### Get example message from stream
Print message to the console for given message name
```cpp
#include <avro/Generic.hh>
avro::GenericRecord sample_message = ncds_client.get_sample_messages("GIDS", "SeqIndexTickDetail", false);
print_record(sample_message);
```

Example output:
```
SeqIndexTickDetail
SoupPartition: 0
SoupSequence: 182012109
msgType: I
timeStamp: 886537340
fpType: I
brand: NQ
series: NQG
instrumentID: NQGB4050LM        
tickValue: 106593206220785
tickDirection: +
currency: USD
```

### Get continuous stream
```cpp
std::string topic = "GIDS";
std::string msg_name = "SeqEtpIpvValue";
ncds_client.get_sample_messages(topic, msg_name, true);
```

## Documentation 
An addition to the example application, there is extra documentation at the package and class level, which are located in project ```https://git.nasdaq.com/gis-lab/mdic/ncds-cpp-sdk/-/tree/dev/ncds-sdk/docs```

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

### Building and Running Tests
Dev Dependencies
- Python 3
- pytest-kafka (`pip install pytest-kafka`)
- Apache kafka >= 2.8.0

To run the tests
- Make sure that your kafka download folder is located in the `ncds-cpp-sdk/test` directory and is named `kafka`
- Open the file `kafka/config/server.properties` and uncomment the lines that say `listeners=PLAINTEXT://:9092` and `advertised.listeners=PLAINTEXT://:9092`. Change these lines to `listeners=PLAINTEXT://localhost:9092` and `advertised.listeners=PLAINTEXT://localhost:9092`
- Move into the test and build directories: ```cd test && mkdir build && cd build```
- Make the test files: ```cmake .. && make```
- Run the python testing script ```cd ../.. && pytest test/RunTests.py```


## License

Code and documentation released under the [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0)
