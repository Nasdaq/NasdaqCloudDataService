//
// Created by Spencer Sortman on 7/27/21.
//

#ifndef TESTS_FOR_TESTS_AVROSERIALIZER_H
#define TESTS_FOR_TESTS_AVROSERIALIZER_H

#include <fstream>
#include <complex>


#include "avro/Compiler.hh"
#include "avro/Encoder.hh"
#include "avro/Decoder.hh"
#include "avro/Specific.hh"
#include "avro/Generic.hh"

class MemoryOutputStream_custom : public avro::OutputStream {
public:
    const size_t chunkSize_;
    std::vector<uint8_t *> data_;
    size_t available_;
    size_t byteCount_;

    explicit MemoryOutputStream_custom(size_t chunkSize) : chunkSize_(chunkSize),
                                                           available_(0), byteCount_(0) {}
    ~MemoryOutputStream_custom() final {
        for (std::vector<uint8_t *>::const_iterator it = data_.begin();
             it != data_.end(); ++it) {
            delete[] * it;
        }
    }

    bool next(uint8_t **data, size_t *len) final {
        if (available_ == 0) {
            data_.push_back(new uint8_t[chunkSize_]);
            available_ = chunkSize_;
        }
        *data = &data_.back()[chunkSize_ - available_];
        *len = available_;
        byteCount_ += available_;
        available_ = 0;
        return true;
    }

    void backup(size_t len) final {
        available_ += len;
        byteCount_ -= len;
    }

    uint64_t byteCount() const final {
        return byteCount_;
    }

    void flush() final {}
};


class AvroSerializer {
public:
    std::pair<char*, size_t> encode(avro::GenericDatum &datum) {
        size_t chunkSize=4 *1024;
        MemoryOutputStream_custom *os = new MemoryOutputStream_custom(chunkSize);

        avro::EncoderPtr e = avro::binaryEncoder();
        e->init(*os);
        avro::encode(*e, datum);
        e->flush();

        size_t count = os->byteCount();
        char* data = new char[count];
        int i=0;

        for (std::vector<uint8_t*>::const_iterator it = os->data_.begin(); it !=os->data_.end() && i<count; ++it) {
            uint8_t* chunk = *it;
            int size = chunkSize;
            for(int j=0; j<size && i<count; j++, i++) {
                data[i] = chunk[j];
            }
        }
        return {data, count};
    }
};


#endif //TESTS_FOR_TESTS_AVROSERIALIZER_H
