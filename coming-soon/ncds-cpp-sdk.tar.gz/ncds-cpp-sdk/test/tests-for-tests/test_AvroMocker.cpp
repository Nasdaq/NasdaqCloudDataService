//
// Created by Spencer Sortman on 7/27/21.
//

#include "../utils/AvroMocker.h"
#include <iostream>
#include <fstream>
#include "../utils/AvroSerializer.h"
#include "../utils/PrintRecords.h"


int main() {
    std::ifstream in("/Users/spesor/Projects/ncds-cpp-sdk/test/ncdsresources/NLSCTA.avsc");
    avro::ValidSchema schema;
    avro::compileJsonSchema(in, schema);

    avro::GenericDatum union_datum(schema);
    if (union_datum.isUnion()) std::cout << "Union" << std::endl;
    std::cout << "Branch: " << union_datum.unionBranch() << std::endl;
    union_datum.selectBranch(1);

    AvroMocker avro_mocker(schema, 1);
    avro::GenericDatum datum = avro_mocker.create_message();
    avro::GenericRecord record = datum.value<avro::GenericRecord>();

    print_record(record);
}