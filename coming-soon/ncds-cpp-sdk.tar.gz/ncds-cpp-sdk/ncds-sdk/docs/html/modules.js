var modules =
[
    [ "consumer", "group__consumer.html", "group__consumer" ],
    [ "internal", "group__internal.html", "group__internal" ],
    [ "ncdsclient", "group__ncdsclient.html", "group__ncdsclient" ]
];