var searchData=
[
  ['deserializemsg_0',['DeserializeMsg',['../classncds_1_1DeserializeMsg.html',1,'ncds']]]
];
