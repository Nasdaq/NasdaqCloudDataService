#include <librdkafka/rdkafkacpp.h>
#include <avro/Generic.hh>
#include <string>
#include "ncds-sdk/NCDSClient.h"
//#include "../ncds-sdk/src/main/cpp.com.nasdaq.ncdsclient/consumer/NasdaqKafkaAvroConsumer.h"
#include "ncds-sdk/AvroDeserializer.h"
#include "ncds-sdk/internal/utils/TestConfigLoader.h"
#include "utils/PrintRecords.h"

using namespace ncds;

void test_list_topics(NCDSClient &ncds_client) {
    std::set<std::string> list = ncds_client.list_topics_for_the_client();
    for (const std::string& topic : list) {
        std::cout << topic;
    }
}

void test_get_schema(NCDSClient &ncds_client) {
    avro::ValidSchema schema = ncds_client.get_schema("GIDS");
    std::cout << "schema: " << schema.toJson();
}

void test_consumer(NCDSClient &ncds_client) {
    //NCDSKafkaConsumer without timestamp
    std::unique_ptr<RdKafka::KafkaConsumer> consumer = ncds_client.NCDSKafkaConsumer("GIDS");
    std::unique_ptr<RdKafka::Message> msg (consumer->consume(10000));

    avro::ValidSchema schema = ncds_client.get_schema("GIDS");
    DeserializeMsg consume(schema);
    avro::GenericRecord message = consume.deserialize_msg(*msg);
    print_record(message);
    //NCDSKafkaConsumer with timestamp
    std::unique_ptr<RdKafka::KafkaConsumer> consumer2 = ncds_client.NCDSKafkaConsumer("GIDS");
    std::unique_ptr<RdKafka::Message> msg2 (consumer2->consume(10000));

    avro::ValidSchema schema2 = ncds_client.get_schema("GIDS");
    DeserializeMsg consume2(schema2);
    avro::GenericRecord message2 = consume2.deserialize_msg(*msg2);
    print_record(message2);
    std::cout << "end of function" << std::endl;
}

void test_top_messages(NCDSClient &ncds_client) {
    //top_messages without timestamp
    auto messages = ncds_client.top_messages("GIDS", 5);
    std::cout << "top messages: " << std::endl;
    print_records(messages);

    //top_messages with timestamp
    auto messages2 = ncds_client.top_messages("GIDS", 1590084446510, 5);
    std::cout << "top messages: " << std::endl;
    print_records(messages2);
}

void test_sample_messages(NCDSClient &ncds_client) {
    auto sample_messages = ncds_client.get_sample_messages("GIDS", "SeqIndexTickDetail", false);
}

void test_end_of_data(NCDSClient &ncds_client) {
    std::unique_ptr<RdKafka::KafkaConsumer> consumer = ncds_client.NCDSKafkaConsumer("GIDS");
    std::cout << "created consumer" << std::endl;
    ncds_client.end_of_data(consumer.get(), "GIDS");
}

bool test_get_sample_message_incorrect_topic(NCDSClient &ncds_client) {
    auto sample_messages = ncds_client.get_sample_messages("NLSCTA", "SeqIndexTickDetail", false);
}

int main() {
    std::unique_ptr<RdKafka::Conf> kafka_config = std::unique_ptr<RdKafka::Conf>(load_test_config());
    std::unordered_map<std::string, std::string> auth_config = load_test_auth_config();
    NCDSClient ncds_client(kafka_config.get(), auth_config);
//    test_list_topics(ncds_client);
//    test_get_schema(ncds_client);
//    test_consumer(ncds_client);
//    test_top_messages(ncds_client);
//    test_sample_messages(ncds_client);
//    test_end_of_data(ncds_client);
    test_get_sample_message_incorrect_topic(ncds_client);

    return 0;
}

