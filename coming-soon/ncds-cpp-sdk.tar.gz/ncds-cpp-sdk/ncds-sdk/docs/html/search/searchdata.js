var indexSectionsWithContent =
{
  0: "acdegiklnrtu",
  1: "adknr",
  2: "n",
  3: "deglnt",
  4: "cinu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Modules"
};

