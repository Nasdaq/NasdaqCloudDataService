//
// Created by Jennifer Wang on 7/27/21.
//

#include "NCDSTestUtil.h"
#include <string>
#include "avro/ValidSchema.hh"
#include "avro/Compiler.hh"
#include "AvroMocker.h"
#include "AvroSerializer.h"
#include <cstdlib>
#include <spdlog/spdlog.h>
#include <thread>         // std::this_thread::sleep_for
#include <chrono>         // std::chrono::seconds
#include "PrintRecords.h"

NCDSTestUtil::NCDSTestUtil() {
    this->delivery_report_cb = std::make_unique<NCDSDeliveryReportCb>();

    // create and set producer config
    std::string errstr;
    this->producer_conf = std::unique_ptr<RdKafka::Conf>(RdKafka::Conf::create(RdKafka::Conf::CONF_GLOBAL));

//    this->producer_conf->set("debug", "all", errstr);
    this->producer_conf->set("bootstrap.servers", "localhost:9092", errstr);
    this->producer_conf->set("client.id", "random client id", errstr);
    this->producer_conf->set("request.timeout.ms", "15000", errstr);
    this->producer_conf->set("dr_cb", this->delivery_report_cb.get(), errstr);

    std::string value;
    producer_conf->get("bootstrap.servers", value);
    std::cout << "bootstrap servers: " << value << "\n";

    add_schemas_to_control_topic();
    push_gids_messages();
    push_mock_messages();
}

std::string get_test_resource_path() {
    // Default path for (https://cmake.org/cmake/help/v3.0/module/GNUInstallDirs.html) DATADIR
    std::string path = "/usr/local/share/ncdsresources/";

    // If the user sets an environment variable, use that instead
    if(const char* env_p = std::getenv("NCDSRESOURCES"))
        path = env_p;

    return path;
}

void NCDSTestUtil::add_schemas_to_control_topic() {
    std::cout << "adding schemas to control topic \n" ;
    std::string nls_key = "NLSUTP";
    std::string gids_key = "GIDS";
    std::string mock_key = "MOCK";

    std::vector<std::string> all_topics{nls_key, gids_key, mock_key};

    std::vector<avro::GenericDatum> all_mock_messages;

    std::string ctrl_schema_file = get_test_resource_path() + "ControlMessageSchema.avsc";
    std::ifstream in(ctrl_schema_file);
    if (!in.good()) {
        throw std::runtime_error("Could not open file: " + ctrl_schema_file);
    }
    avro::ValidSchema ctrl_schema;
    avro::compileJsonSchema(in, ctrl_schema);

    // instantiate mocker
    AvroMocker avro_mocker = AvroMocker(ctrl_schema, 1);
    std::cout << "avro mocker instantiated \n";
    for (const std::string topic : all_topics) {
        std::string topic_file_path = "test/ncdsresources/test" + topic + ".avsc";
        std::ifstream in(topic_file_path);
        avro::ValidSchema schema;
        avro::compileJsonSchema(in, schema);

        avro::GenericDatum message = avro_mocker.create_message(&ctrl_branch);
        avro::GenericRecord &record = message.value<avro::GenericRecord>();

        size_t schema_idx = record.fieldIndex("schema");
        avro::GenericDatum schema_datum(schema.toJson());
        record.setFieldAt(schema_idx, schema_datum);
        size_t name_idx = record.fieldIndex("name");
        avro::GenericDatum topic_datum(topic);
        record.setFieldAt(name_idx, topic_datum);

        std::cout << "push message to all_mock_messages \n";
        all_mock_messages.push_back(message);
        std::cout << "adding topic to topics_on_stream \n";
        this->topics_on_stream.insert(topic);
    }

    std::cout << "mock messages created? \n";

    std::string create_producer_error;
    std::unique_ptr<RdKafka::Producer> producer = std::unique_ptr<RdKafka::Producer>(RdKafka::Producer::create(this->producer_conf.get(), create_producer_error));
    if (!producer) {
        std::cout << "failed to create producer in push_mock_messages: " << create_producer_error << "\n";
    }

    for (avro::GenericDatum &mock_msg : all_mock_messages) {
        avro::GenericRecord record = mock_msg.value<avro::GenericRecord>();
        AvroSerializer control_message_serializer = AvroSerializer();
        auto encoded_message = control_message_serializer.encode(mock_msg);
        void* data = (void*) encoded_message.first;
        size_t len = encoded_message.second;

        RdKafka::ErrorCode error_code = producer->produce(this->ctrl_topic, 0, 0, data, len, NULL, 0, NULL, NULL);
        if (error_code != RdKafka::ERR_NO_ERROR) {
            std::cout << "error occurred while producing: " << err2str(error_code);
        }
        producer->poll(0);
    }
    RdKafka::ErrorCode flush_error = producer->flush(10000);
    if (flush_error != RdKafka::ERR_NO_ERROR) {
        std::cout << "error happened during flush: " << err2str(flush_error) << "\n";
    }

}

std::set<std::string> NCDSTestUtil::get_added_topics() {
    return this->topics_on_stream;
}

std::vector<avro::GenericRecord> NCDSTestUtil::get_mock_messages() {
    return this->mock_messages_on_stream;
}

std::vector<avro::GenericRecord> NCDSTestUtil::get_GIDS_messages() {
    return this->GIDS_messages_on_stream;
}

avro::ValidSchema NCDSTestUtil::get_schema_for_topic(std::string schema_file) {
    std::ifstream in("test/ncdsresources/test"+schema_file+".avsc");
    avro::ValidSchema schema;
    avro::compileJsonSchema(in, schema);
    return schema;
}

void NCDSTestUtil::push_mock_messages() {
    std::cout << "start pushing mock messages \n";
    // get mock messages
    auto mock_messages = this->get_mocker_generic_record(5);
    std::string mock_schema_file = "test/ncdsresources/testMOCK.avsc";

    // create producer
    std::string create_producer_error;
    std::unique_ptr<RdKafka::Producer> mocker_producer = std::unique_ptr<RdKafka::Producer>(RdKafka::Producer::create(this->producer_conf.get(), create_producer_error));
    if (!mocker_producer) {
        std::cout << "failed to create producer in push_mock_messages: " << create_producer_error << "\n";
    }
    // add mock records to topic
    for (avro::GenericDatum &mock_msg : mock_messages) {
        this->mock_messages_on_stream.push_back(mock_msg.value<avro::GenericRecord>());
        AvroSerializer mocker_serializer = AvroSerializer();
        auto encoded_message = mocker_serializer.encode(mock_msg);
        RdKafka::ErrorCode error_code = mocker_producer->produce(this->mock_data_stream, 0, 0, encoded_message.first, encoded_message.second, NULL, 0, NULL, NULL);
        if (error_code != RdKafka::ERR_NO_ERROR) {
            std::cout << "error occurred while producing: " << err2str(error_code) << "\n";
        }
        // need to sleep between producing messages so timestamp is different
        std::this_thread::sleep_for(std::chrono::seconds(3));
    }

    RdKafka::ErrorCode flush_error =  mocker_producer->flush(10000);
    if (flush_error != RdKafka::ERR_NO_ERROR) {
        std::cout << "flush error in push_mock_messages: " << err2str(flush_error) << "\n";
    }
}

std::vector<avro::GenericDatum> NCDSTestUtil::get_mocker_generic_record(int num_records) {
    std::ifstream in("test/ncdsresources/testMOCK.avsc");
    avro::ValidSchema mocker_schema;
    avro::compileJsonSchema(in, mocker_schema);

    //create mocker
    AvroMocker avro_mocker = AvroMocker(mocker_schema, num_records);
    return avro_mocker.generate_mock_messages();
}

void NCDSTestUtil::push_gids_messages() {
    std::cout << "start pushing gids messages \n";
    // get mock messages
    auto GIDS_messages = this->get_GIDS_generic_record(5);

    for (auto message : GIDS_messages) {
        auto record = message.value<avro::GenericRecord>();
        std::cout << "Message name: " << record.schema()->name().simpleName() << std::endl;
        print_record(record);
    }
    // create producer
    std::string create_producer_error;
    std::unique_ptr<RdKafka::Producer> GIDS_producer = std::unique_ptr<RdKafka::Producer>(RdKafka::Producer::create(this->producer_conf.get(), create_producer_error));
    if (!GIDS_producer) {
        std::cout << "failed to create producer in push_gids_messages: " << create_producer_error << "\n";
    }
    // add GIDS records to topic
    for (avro::GenericDatum &msg : GIDS_messages) {
        this->GIDS_messages_on_stream.push_back(msg.value<avro::GenericRecord>());

        AvroSerializer serializer = AvroSerializer();
        auto encoded_message = serializer.encode(msg);
        RdKafka::ErrorCode error_code = GIDS_producer->produce(this->GIDS_data_stream, 0, 0, encoded_message.first, encoded_message.second, NULL, 0, NULL, NULL);
        if (error_code != RdKafka::ERR_NO_ERROR) {
            std::cout << "error occurred while producing: " << err2str(error_code) << "\n";
        }
    }

    RdKafka::ErrorCode flush_error =  GIDS_producer->flush(10000);
    if (flush_error != RdKafka::ERR_NO_ERROR) {
        std::cout << "flush error in push_gids_messages: " << err2str(flush_error) << "\n";
    }
}

std::vector<avro::GenericDatum> NCDSTestUtil::get_GIDS_generic_record(int num_records) {
    std::ifstream in("test/ncdsresources/testGIDS.avsc");
    avro::ValidSchema schema;
    avro::compileJsonSchema(in, schema);

    //create mocker
    AvroMocker avro_mocker = AvroMocker(schema, num_records);
    size_t idx1 = 1;
    size_t idx2 = 3;
    std::vector<avro::GenericDatum> records = avro_mocker.generate_mock_messages(&idx1);
    std::vector<avro::GenericDatum> ipv_records = avro_mocker.generate_mock_messages(&idx2);

    records.insert( records.end(), ipv_records.begin(), ipv_records.end() ); // found off stack overflow
    return records;
}


bool NCDSTestUtil::compare_records(avro::GenericRecord record1, avro::GenericRecord record2) {
    if (record1.fieldCount() != record2.fieldCount()) {
        return false;
    }
    for (size_t i=0; i<record1.fieldCount(); i++) {
        avro::GenericDatum datum1 = record1.fieldAt(i);
        avro::GenericDatum datum2 = record2.fieldAt(i);
        if (datum1.type() != datum2.type()) {
            return false;
        } else {
            if (datum1.type() == avro::AVRO_DOUBLE) {
                double field1 = datum1.value<double>();
                double field2 = datum2.value<double>();
                if (field1 != field2) {
                    std::cout << "fields don't match: " << std::to_string(field1) << ", " << std::to_string(field2) << std::endl;
                    return false;
                }
            } else if (datum1.type() == avro::AVRO_LONG) {
                int64_t field1 = datum1.value<int64_t>();
                int64_t field2 = datum2.value<int64_t>();
                if (field1 != field2) {
                    std::cout << "fields don't match: " << std::to_string(field1) << ", " << std::to_string(field2) << std::endl;
                    return false;
                }
            } else if (datum1.type() == avro::AVRO_STRING) {
                std::string field1 = datum1.value<std::string>();
                std::string field2 = datum1.value<std::string>();
                if (field1 != field2) {
                    std::cout << "fields don't match: " << field1 << ", " << field2 << std::endl;
                    return false;
                }
            } else if (datum1.type() == avro::AVRO_INT) {
                int field1 = datum1.value<int>();
                int field2 = datum1.value<int>();
                if (field1 != field2) {
                    std::cout << "fields don't match: " << std::to_string(field1) << ", " << std::to_string(field2) << std::endl;
                    return false;
                }
            } else {
                std::cout << "datum type was not a double, long, int or string" << std::endl;
            }
        }
    }
    return true;
}
