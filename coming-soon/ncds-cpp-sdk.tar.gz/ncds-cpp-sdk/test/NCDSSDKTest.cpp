//
// Created by Jennifer Wang on 7/27/21.
//

#ifndef NCDSSDKTEST_H
#define NCDSSDKTEST_H

#include "utils/NCDSTestUtil.h"
#include "ncds-sdk/NCDSClient.h"
#include "avro/ValidSchema.hh"
#include "ncds-sdk/AvroDeserializer.h"
#include "ncds-sdk/internal/utils/TestConfigLoader.h"
#include "utils/PrintRecords.h"
#include <cassert>
#include <sstream>


void debug(std::string msg) {
    std::cout << "*******************************" << std::endl;
    std::cout << msg << std::endl;
    std::cout << "*******************************" << std::endl;
}

void test_list_topics_for_client(NCDSTestUtil &ncds_test_util) {
    std::cout << "starting test...\n";
    std::unordered_map<std::string, std::string> security_cfg = {};
    std::cout << "passing nullptr and empty cfg into ncds client \n";
    ncds::NCDSClient ncds_client = ncds::NCDSClient(nullptr, security_cfg);
    std::cout << "created ncds client \n";
    std::set<std::string> topics = ncds_client.list_topics_for_the_client();
    std::set<std::string> added_topics = ncds_test_util.get_added_topics();
    for (std::string topic : topics) {
        std::cout << "topics: " << topic << "\n";
    }
    for (std::string topic: added_topics) {
        std::cout << "added topics: " << topic << "\n";
    }
    assert(topics == added_topics);
    std::cout << "test passed! \n";
}

void test_get_schema_for_topic(NCDSTestUtil &ncds_test_util) {
    std::unordered_map<std::string, std::string> security_cfg = {};
    ncds::NCDSClient ncds_client = ncds::NCDSClient(nullptr, security_cfg);
    std::string topic = "GIDS";
    avro::ValidSchema schema_from_sdk = ncds_client.get_schema(topic);

    avro::ValidSchema schema_from_file = ncds_test_util.get_schema_for_topic(topic);

    assert(schema_from_sdk.toJson() == schema_from_file.toJson());
    std::cout << "test passed! \n";
}

void test_insertion(NCDSTestUtil &ncds_test_util) {
    // get mock messages
    std::vector<avro::GenericRecord> mock_messages = ncds_test_util.get_mock_messages();
    std::vector<avro::GenericRecord> mock_records_from_kafka;
    std::string topic = "MOCK";

    std::unordered_map<std::string, std::string> security_cfg = {};
    ncds::NCDSClient ncds_client = ncds::NCDSClient(nullptr, security_cfg);
    auto messages = ncds_client.top_messages(topic, 5);
    std::cout << "retrieved top messages \n";
    avro::ValidSchema mock_schema = ncds_test_util.get_schema_for_topic(topic);
    for (avro::GenericRecord &msg : messages) {
        mock_records_from_kafka.push_back(msg);
    }

    // compare messages
    assert(mock_messages.size() == mock_records_from_kafka.size());
    for (int i = 0; i<mock_messages.size(); i++) {
        assert(NCDSTestUtil::compare_records(mock_messages.at(i), mock_records_from_kafka.at(i)));
    }
    std::cout << "test passed!"  << std::endl;
}

void test_top_messages_with_timestamp(NCDSTestUtil &ncds_test_util) {
    std::string topic = "MOCK";
    std::vector<avro::GenericRecord> mock_records = ncds_test_util.get_mock_messages();

    RdKafka::MessageTimestamp message_timestamp = ncds_test_util.delivery_report_cb.get()->timestamp_to_seek_to;
    long timestamp = message_timestamp.timestamp;
    std::cout << "timestamp: " << std::to_string(timestamp) << std::endl;

    std::unordered_map<std::string, std::string> security_cfg = {};
    ncds::NCDSClient ncds_client = ncds::NCDSClient(nullptr, security_cfg);
    std::vector<avro::GenericRecord> records = ncds_client.top_messages(topic, timestamp, 10);

    print_records(records);

    assert(records.size() == 3);
    for (int i = 0; i<records.size(); i++) {
        assert(NCDSTestUtil::compare_records(records[i], mock_records[i+2]));
    }
    std::cout << "test passed!" << std::endl;
}

void test_get_sample_messages(NCDSTestUtil &ncds_test_util) {
    // get mock messages
    std::vector<avro::GenericRecord> mock_messages = ncds_test_util.get_mock_messages();
    avro::GenericRecord mock_record = mock_messages.front();
    std::vector<avro::GenericRecord> mock_records_from_kafka;
    std::string topic = "MOCK";
    std::string msg_name = "SeqEtpIpvValue";

    std::unordered_map<std::string, std::string> security_cfg = {};
    ncds::NCDSClient ncds_client = ncds::NCDSClient(nullptr, security_cfg);
    avro::GenericRecord record =  ncds_client.get_sample_messages(topic, msg_name, false);

    assert(NCDSTestUtil::compare_records(mock_record, record));
    std::cout << "test passed!"  << std::endl;
}

void test_get_all_sample_messages(NCDSTestUtil &ncds_test_util) {
    // get GIDS messages
    std::vector<avro::GenericRecord> GIDS_messages = ncds_test_util.get_GIDS_messages();

    print_records(GIDS_messages);

    std::string topic = "GIDS";
    std::string msg_name = "SeqEtpIpvValue";

    std::unordered_map<std::string, std::string> security_cfg = {};
    ncds::NCDSClient ncds_client = ncds::NCDSClient(nullptr, security_cfg);

    // Redirect cout
    std::streambuf* old_buf = std::cout.rdbuf();
    std::ostringstream str_cout;
    std::cout.rdbuf( str_cout.rdbuf() );

    ncds_client.get_sample_messages(topic, msg_name, true);

    // Restore old cout.
    std::cout.rdbuf( old_buf );

    std::string output = str_cout.str();
    std::stringstream ss(output);
    std::string line;

    int msg_name_count = 0;
    while (std::getline(ss, line)) {
        std::cout << line << std::endl;
        if (line == msg_name) {
            msg_name_count++;
        } else if (line == "SeqEquitiesSummary") {
            assert(false);
        }
    }
    assert (msg_name_count == 5);
    std::cout << "test passed! \n";
}

void test_get_sample_message_incorrect_topic(NCDSTestUtil &ncds_test_util) {
    std::vector<avro::GenericRecord> mock_messages = ncds_test_util.get_mock_messages();
    avro::GenericRecord mock_record = mock_messages.front();
    std::vector<avro::GenericRecord> mock_records_from_kafka;
    std::string topic = "MUCK";
    std::string msg_name = "SeqEtpIpvValue";

    try {
        std::unordered_map<std::string, std::string> security_cfg = {};
        ncds::NCDSClient ncds_client = ncds::NCDSClient(nullptr, security_cfg);
        avro::GenericRecord record = ncds_client.get_sample_messages(topic, msg_name, false);
    }
    catch (avro::Exception) {
        std::cout << "test passed!";
    }
}

void test_get_schema_for_the_incorrect_topic(NCDSTestUtil & ncds_test_util) {
    std::unordered_map<std::string, std::string> security_cfg = {};
    ncds::NCDSClient ncds_client = ncds::NCDSClient(nullptr, security_cfg);
    std::string topic = "GIDS";
    avro::ValidSchema schema_from_sdk = ncds_client.get_schema("MOCK");

    avro::ValidSchema schema_from_file = ncds_test_util.get_schema_for_topic(topic);

    assert(schema_from_sdk.toJson() != schema_from_file.toJson());
    std::cout << "test passed!";
}

int main() {
    debug("Running NCDS SDK tests... \n");
    NCDSTestUtil ncds_test_util;

    debug("Test List Topics For Client\n");
    test_list_topics_for_client(ncds_test_util);

    debug("Test Get Schema For Topic \n");
    test_get_schema_for_topic(ncds_test_util);

    debug("Test Inserting Messages \n");
    test_insertion(ncds_test_util);

    debug("Test Top Messages With Timestamp \n");
    test_top_messages_with_timestamp(ncds_test_util);

    debug("Test Get Sample Message \n");
    test_get_sample_messages(ncds_test_util);

    debug("Test Get All Sample Messages \n");
    test_get_all_sample_messages(ncds_test_util);

    debug("Test Get Sample Message With Incorrect Topic");
    test_get_sample_message_incorrect_topic(ncds_test_util);

    debug("Test Get Schema For Incorrect Topic");
    test_get_schema_for_the_incorrect_topic(ncds_test_util);
}


#endif //NCDSSDKTEST_H
