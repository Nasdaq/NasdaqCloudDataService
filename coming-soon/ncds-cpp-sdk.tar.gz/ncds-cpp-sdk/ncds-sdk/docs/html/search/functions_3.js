var searchData=
[
  ['list_5ftopics_5ffor_5fthe_5fclient_0',['list_topics_for_the_client',['../classncds_1_1NCDSClient.html#a400ccc1fa8f58878573333e6bd0b6448',1,'ncds::NCDSClient']]]
];
