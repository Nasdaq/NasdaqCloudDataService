//
// Created by Spencer Sortman on 7/27/21.
//

#include <iostream>
#include <fstream>
#include "../utils/AvroSerializer.h"
#include "../utils/AvroMocker.h"
#include "../utils/PrintRecords.h"
#include "../../ncds-sdk/include/AvroDeserializer.h"


int main() {
    std::ifstream in("/Users/spesor/Projects/ncds-cpp-sdk/test/ncdsresources/NLSCTA.avsc");
    avro::ValidSchema schema;
    avro::compileJsonSchema(in, schema);

    AvroMocker avro_mocker(schema, 1);
    size_t branch = 1;
    avro::GenericDatum datum = avro_mocker.create_message(&branch);

    AvroSerializer serializer;

    std::pair<char*, size_t> bytes = serializer.encode(datum);

    for (int i = 0; i < bytes.second; i++) {
        std::cout << bytes.first[i];
    }
    std::cout << std::endl;

//    std::ifstream in2("/Users/spesor/Projects/ncds-cpp-sdk/test/ncdsresources/NLSCTA.avsc");
//    avro::ValidSchema schema_deserializer;
//    avro::compileJsonSchema(in2, schema_deserializer);

    AvroDeserializer deserializer(schema);

    uint8_t *bytes_uint8 = (uint8_t *) bytes.first;

    std::cout << std::endl;

    avro::GenericRecord record = deserializer.decode(bytes_uint8, bytes.second);


    std::cout << "START OF RECORD" << std::endl;
    print_record(record);
    std::cout << "END OF RECORD" << std::endl;
}
