//
// Created by Spencer Sortman on 7/27/21.
//

#ifndef NCDS_SDK_AVROMOCKER_H
#define NCDS_SDK_AVROMOCKER_H

#include <random>
#include <cstdlib>
#include <ctime>
#include <chrono>


#include "avro/Compiler.hh"
#include "avro/Encoder.hh"
#include "avro/Decoder.hh"
#include "avro/Specific.hh"
#include "avro/Generic.hh"


const int MAX = 26;
std::string get_rand_string(int n)
{
    char alphabet[MAX] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g',
                           'h', 'i', 'j', 'k', 'l', 'm', 'n',
                           'o', 'p', 'q', 'r', 's', 't', 'u',
                           'v', 'w', 'x', 'y', 'z' };

    std::string res = "";
    std::srand(time(0));

    for (int i = 0; i < n; i++)
        res = res + alphabet[std::rand() % MAX];

    return res;
}


class AvroMocker {
public:
    avro::ValidSchema schema;
    int num_records;
    AvroMocker(avro::ValidSchema &schema, int num_records) : schema(schema), num_records(num_records) {}

    avro::GenericDatum create_message(size_t * union_branch = nullptr) {
        avro::GenericDatum generic_datum(schema);

        // If we are dealing with a union schema, select the appropriate branch
        if (union_branch != nullptr) {
            generic_datum.selectBranch(*union_branch);
        }

        avro::GenericRecord &record = generic_datum.value<avro::GenericRecord>();
        std::srand(time(0));

        for (size_t i = 0; i < record.fieldCount(); i++) {
            avro::GenericDatum datum = record.fieldAt(i);

            if (datum.type() == avro::AVRO_DOUBLE) {
                double lower_bound = 0;
                double upper_bound = 100000;
//                std::uniform_real_distribution<double> unif(lower_bound,upper_bound);
//                std::default_random_engine engine; // or any other engine
//                engine.seed(std::chrono::system_clock::now().time_since_epoch().count());
                //double a_random_double = unif(engine);
                double a_random_double = rand() % 10000;

                avro::GenericDatum v(a_random_double);
                record.setFieldAt(i, v);
            }

            else if (datum.type() == avro::AVRO_INT) {
                int lower_bound = 0;
                int upper_bound = 100000;
//                std::uniform_real_distribution<int> unif(lower_bound,upper_bound);
//                std::default_random_engine engine; // or any other engine
//                engine.seed(std::chrono::system_clock::now().time_since_epoch().count());
//                int a_random_int = unif(engine);

                int a_random_int = rand() % 10000;

                avro::GenericDatum v(a_random_int);
                record.setFieldAt(i, v);
            }

            else if (datum.type() == avro::AVRO_LONG) {
                int64_t lower_bound = 0;
                int64_t upper_bound = 100000;
//                std::uniform_real_distribution<int64_t> unif(lower_bound,upper_bound);
//                std::default_random_engine engine; // or any other engine
//                engine.seed(std::chrono::system_clock::now().time_since_epoch().count());
//                int64_t a_random_long = unif(engine);

                int64_t a_random_long = rand() % 10000;


                avro::GenericDatum v(a_random_long);
                record.setFieldAt(i, v);
            }

            else if (datum.type() == avro::AVRO_STRING) {
                std::string a_random_string = get_rand_string(10);
                avro::GenericDatum v(a_random_string);
                record.setFieldAt(i, v);
            }
        }
        
        return generic_datum;
    }

    std::vector<avro::GenericDatum> generate_mock_messages(size_t * union_branch = nullptr) {
        std::vector<avro::GenericDatum> records;
        for (int i = 0; i < this->num_records; i++) {
            records.push_back(create_message(union_branch));
        }
        return records;
    }
};



#endif //NCDS_SDK_AVROMOCKER_H
