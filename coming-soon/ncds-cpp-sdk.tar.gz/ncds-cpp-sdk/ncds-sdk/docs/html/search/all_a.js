var searchData=
[
  ['top_5fmessages_0',['top_messages',['../classncds_1_1NCDSClient.html#a9a9225b566e1cd46b231b27e5b826b98',1,'ncds::NCDSClient::top_messages(const std::string &amp;topic_name, int num_messages)'],['../classncds_1_1NCDSClient.html#a0819df4ef1e66bd310522c38a9364696',1,'ncds::NCDSClient::top_messages(const std::string &amp;topic_name, long timestamp, int num_messages)']]]
];
