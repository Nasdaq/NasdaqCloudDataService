var group__ncdsclient =
[
    [ "ncds", "namespacencds.html", null ]
];