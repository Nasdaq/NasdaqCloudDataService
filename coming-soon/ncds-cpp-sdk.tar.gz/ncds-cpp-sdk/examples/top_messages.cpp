//
// Created by Spencer Sortman on 8/10/21.
//

#include <ncds-sdk/NCDSClient.h>
#include <librdkafka/rdkafkacpp.h>
#include <unordered_map>
#include "PrintRecords.h"
#include "GetConfigs.h"

int main() {
    // Main class for consuming NCDS data
    std::unique_ptr<RdKafka::Conf> kafka_config = get_kafka_config();
    std::unordered_map<std::string, std::string> auth_config = get_auth_config();

    ncds::NCDSClient ncds_client(kafka_config.get(), auth_config);

    // Consume the top message in the GIDS topic
    auto messages = ncds_client.top_messages("GIDS", 1);
    std::cout << "Top Message For Stream: " << "\n" << "\n";
    print_records(messages);
}

