# Nasdaq Cloud Data Service (NCDS) Dockerfiles

## Building
Run docker build in project home directory

```
docker build -f docker/Dockerfile . -t sdk-app 
```

## Running Locally Built Images

Replace `{client-id-value}`, `{client-secret-value}`, `{broker-list}`, `{token-endpoint}` which are provided during on-boarding from Nasdaq team. 

Replace `{topic}` with the desired topic.  

Replace `{ssl-ca-location}` with the full path to the certificate file or leave it as an empty string ""
if a certificate is not being used. 

```
docker run -e CLIENT_ID={client-id-value} -e CLIENT_SECRET={client-secret-value} -e BROKERS={broker-list} -e TOKEN_ENDPOINT={token-endpoint} -e SSL_CA_LOCATION={ssl-ca-location} -e TOPIC={topic} sdk-app:latest
```

The image will run `ncds_kafka_consumer_env.cpp` in the `examples/` directory. 

## Nasdaq Cloud Data Service - Kafka mirroring with MirrorMaker
Kafka's mirroring feature makes it possible to maintain a replica of an existing Kafka cluster. (https://github.com/Nasdaq/CloudDataService/tree/master/docker/mirrormaker)     