var classNCDSClient =
[
    [ "end_of_data", "classNCDSClient.html#a4a2530d759892b1a4097881a28f0ae2e", null ],
    [ "get_sample_messages", "classNCDSClient.html#aad791902bb22cc374081418287a64376", null ],
    [ "get_schema", "classNCDSClient.html#afbd4e6e7609b12ef19a1004453309e5f", null ],
    [ "list_topics_for_the_client", "classNCDSClient.html#a64fefd29ad2365a63c2a89d555e4e462", null ],
    [ "NCDSKafkaConsumer", "classNCDSClient.html#a6a166bf96d5fd5c397eeb2cba0da62e5", null ],
    [ "NCDSKafkaConsumer", "classNCDSClient.html#a0b118b095e46550e82d9462db9166ce1", null ],
    [ "top_messages", "classNCDSClient.html#ad4b3435b0ceca07a2343420d16d572d6", null ],
    [ "top_messages", "classNCDSClient.html#adaff95ebf377a60a6d9eb896b2d5a080", null ]
];