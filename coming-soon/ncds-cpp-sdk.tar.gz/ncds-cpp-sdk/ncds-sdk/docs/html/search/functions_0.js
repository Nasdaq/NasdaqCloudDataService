var searchData=
[
  ['deserialize_5fmsg_0',['deserialize_msg',['../classncds_1_1DeserializeMsg.html#a32bfccd137b9c0ac623d793dd9374700',1,'ncds::DeserializeMsg']]],
  ['deserializemsg_1',['DeserializeMsg',['../classncds_1_1DeserializeMsg.html#ab0ae380d118d371a06b8f1d22ddb2f49',1,'ncds::DeserializeMsg']]]
];
