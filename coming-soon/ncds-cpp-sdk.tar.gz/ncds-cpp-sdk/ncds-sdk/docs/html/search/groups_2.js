var searchData=
[
  ['ncdsclient_0',['ncdsclient',['../group__ncdsclient.html',1,'']]]
];
