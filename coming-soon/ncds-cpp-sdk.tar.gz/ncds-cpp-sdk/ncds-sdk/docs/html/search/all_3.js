var searchData=
[
  ['end_5fof_5fdata_0',['end_of_data',['../classncds_1_1NCDSClient.html#a9eb2c8e1fed20b3286f34d3af2339557',1,'ncds::NCDSClient']]]
];
