//
// Created by Spencer Sortman on 9/23/21.
//
#include <ncds-sdk/NCDSClient.h>
#include <ncds-sdk/AvroDeserializer.h>
#include <avro/Generic.hh>
#include <string>
#include <memory>
#include <vector>
#include "PrintRecords.h"
#include "GetConfigs.h"

int main() {
    std::unique_ptr<RdKafka::Conf> kafka_config = get_kafka_config();
    auto auth_config = get_auth_config();

    int ms_timeout = 10000;
    std::string topic = "GIDS";

    ncds::NCDSClient ncds_client(kafka_config.get(), auth_config);

    std::unique_ptr<RdKafka::KafkaConsumer> kafka_consumer = ncds_client.NCDSKafkaConsumer(topic);
    std::unique_ptr<RdKafka::Message> message = std::unique_ptr<RdKafka::Message> (kafka_consumer->consume(ms_timeout));

    avro::ValidSchema schema = ncds_client.get_schema(topic);
    ncds::DeserializeMsg deserializer(schema);

    if (message->payload() != NULL) {
        avro::GenericRecord record = deserializer.deserialize_msg(*message);
        std::vector<avro::GenericRecord> v = {record};
        print_records(v);
    }
    else {
        std::cout << "Message payload was null" << std::endl;
    }
}