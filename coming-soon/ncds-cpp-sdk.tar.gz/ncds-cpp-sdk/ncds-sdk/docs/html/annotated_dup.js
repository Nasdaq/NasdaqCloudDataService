var annotated_dup =
[
    [ "ncds", "namespacencds.html", [
      [ "DeserializeMsg", "classncds_1_1DeserializeMsg.html", "classncds_1_1DeserializeMsg" ],
      [ "NCDSClient", "classncds_1_1NCDSClient.html", "classncds_1_1NCDSClient" ]
    ] ],
    [ "AuthenticationConfigLoader", "classAuthenticationConfigLoader.html", null ],
    [ "KafkaConfigLoader", "classKafkaConfigLoader.html", null ],
    [ "NasdaqKafkaAvroConsumer", "classNasdaqKafkaAvroConsumer.html", "classNasdaqKafkaAvroConsumer" ],
    [ "ReadSchemaTopic", "classReadSchemaTopic.html", null ]
];